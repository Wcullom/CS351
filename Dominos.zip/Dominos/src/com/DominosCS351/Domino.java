package com.DominosCS351;


public class Domino
{
    int s1;
    int s2;

    public Domino(int s1, int s2)
    {
        this.s1 = s1;
        this.s2 = s2;

    }

    public  int getS1()

    {
        return s1;
    }

    public void setS1(int ns1)
    {
        this.s1 = ns1;
    }

    public int getS2()
    {
        return s2;
    }

    public void setS2(int ns2)
    {
        this.s2 = ns2;
    }

}

